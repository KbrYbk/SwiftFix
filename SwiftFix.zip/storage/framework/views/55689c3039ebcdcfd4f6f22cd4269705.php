

<?php $__env->startSection('content'); ?>
<div class="container pt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Добавление нового бренда</div>
                <div class="card-body">
                    <form action="<?php echo e(route('brands.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group mb-3">
                            <label for="name">Название бренда</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>

                        <div class="form-group mb-3">
                            <label for="img">Изображение бренда</label>
                            <input type="file" name="img" class="form-control-file" required>
                        </div>

                        <div class="form-group mb-3">
                            <label for="img_slogan">Изображение телефона на отдельной странице бренда</label>
                            <input type="file" name="img_slogan" class="form-control-file" required>
                        </div>

                        <div class="form-group">
                            <label for="color">Выберите цвет фона на отдельной странице бренда:</label>
                            <input type="color" name="color" id="color">
                        </div>

                        <div class="form-group">
                            <label for="text">Выберите цвет текста на отдельной странице бренда:</label>
                            <input type="color" name="text" id="text">
                        </div>

                        <button type="submit" class="btn btn-outline-secondary">Добавить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\SwiftFix\resources\views/addbrand.blade.php ENDPATH**/ ?>