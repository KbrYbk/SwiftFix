

<?php $__env->startSection('content'); ?>
<!-- _________________________________Slogan_____________________________________________________ -->
<section class="slogan-container">
    <div class="container">
        <div class="slogan mb-5 row align-items-center">
            <div class="col-lg-6 order-lg-2">
                <h2 class="mb-4 slogan-top">Ремонт телефонов любой сложности</h2>
                <h2 class="slogan-text">Восстановите свою мобильную жизнь в мгновение ока!</h2>
            </div>
            <div class="col-lg-6 order-lg-1">
                <img src="<?php echo e(url('/img')); ?>/pixel.png" alt="pixel7" class="pixel_on_slogan w-100">
            </div>
        </div>

    </div>
</section>
<!-- _________________________________Brand plates_______________________________________________ -->
<section class="container my-4">
    <h1 class="text-center my-5 name-section">Выберите модель вашего устройства</h1>
    <nav class="menu d-flex">
        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="nav-scroller__item">
            <a href="<?php echo e(url('/brandpage')); ?>/<?php echo e($bp->id); ?>" class="link-brand">
                <div class="card cards-brands">
                    <img src="<?php echo e(asset('images/' . $bp->img)); ?>" alt="logo_brands" class="card-img-top">
                    <div class="card-body  d-flex align-items-center justify-content-center">
                        <h5 class="card-title-brand text-center"><?php echo e($bp->name); ?></h5>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
</section>
<!-- _________________________________Callback Form______________________________________________ -->
<section class="container my-4 ">
    <h1 class="text-center name-section mt-4">Нет подходящего бренда?</h1>
    <form action="<?php echo e(route('callback')); ?>" method="POST" class="mt-5 p-5 main-form">
        <h1 class="text-center mb-4 name-block">Напишите модель вашего устройства,<br>мы вам обязательно позвоним</h1>
        <?php echo csrf_field(); ?>
        <div class="row align-items-center">
            <div class="col-12 col-lg mb-3">
                <input type="text" name="device_model" id="device_model" class="form-control" placeholder="Модель вашего устройства" required>
                <?php $__errorArgs = ['device_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg mb-3">
                <input type="text" name="name" id="name" class="form-control" placeholder="Ваше имя" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg mb-3">
                <input type="text" name="phone_number" id="phone_number" class="form-control" placeholder=" Ваш номер телефона" required>
                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg-2 mb-3 text-center">
                <button type="submit" class="btn btn-outline-secondary">Расчитать стоимость</button>
            </div>
        </div>
    </form>
    <div id="message"></div>
    <script>
        $(document).ready(function() {
            $('.main-form').submit(function(e) {
                e.preventDefault(); // Предотвратить отправку формы

                var form = $(this);
                var url = form.attr('action');

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: form.serialize(), // Сериализовать данные формы
                    success: function(response) {
                        if (response.message === 'Форма успешно отправывыалена') {
                            // Вывести сообщение об успешной отправке
                            $('#message').html('<div class="alert alert-success">'+response.message+'</div>'); // выводим сообщение об успехе
                            form.trigger('reset'); // Сбросить поля формы
                        }
                    },
                    error: function() {
                        alert('Ошибка при отправке формы. Пожалуйста, попробуйте еще раз.');
                    }
                });
            });
        });
    </script>


</section>
<!-- _________________________________Additional services______________________________________________ -->
<section class="container my-4">
    <h1 class="text-center name-section my-5">Полная защита вашего телефона</h1>
    <div class="row additional_services align-items-center g-0">
        <div class="col-lg-6 order-lg-2 text-center">
            <h1 class="name-section mb-5 additional_services_name">Спасём от повторного <br>посещения</h1>
            <h4 class="additional_services_text">После ремонта в нашем сервисе установим на ваше устройство защитное стекло в подарок</h4>
        </div>
        <div class="col-lg-6 order-lg-1">
            <img src="<?php echo e(url('img/')); ?>/AdditionalServices.png" class="AdditionalServices_img w-100" alt="">
        </div>
    </div>
</section>
<!-- ______________________________Review__________________________________________ -->
<section class="container my-4" id="review">
    <h1 class="text-center name-section my-5">Отзывы наших клиентов</h1>
    <div class="row row-cols-1 row-cols-lg-2">
        <div class="col mb-4">
            <div class="card card_rev p-4 h-100">
                <div class="card-body card-body-rev">
                    <div class="row">
                        <div class="col-12 col-md-3 mb-3">
                            <img src="<?php echo e(url('img/review')); ?>/Gosling.png" alt="review_avatar">
                        </div>
                        <div class="col">
                            <h5 class="card-title review-name mb-3">Гослинг</h5>
                            <p class="card-text review-text">Реально классно спасибо за быструю работу!!!1!</p>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex card-footer-review">
                    <div class="rating-result me-auto">
                        <span class="active"></span>
                        <span class="active"></span>
                        <span class="active"></span>
                        <span class="active"></span>
                        <span class="active"></span>
                    </div>
                    <div class="date ms-auto mt-4">
                        <p>15.03.2023</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col mb-4 ">
            <div class="card card_rev p-4 h-100">
                <div class="card-body card-body-rev ">
                    <div class="row">
                        <div class="col-12 col-md-3 mb-3">
                            <img src="<?php echo e(url('img/review')); ?>/Derden.png" alt="review_avatar">
                        </div>
                        <div class="col">
                            <h5 class="card-title review-name mb-3">Кто</h5>
                            <p class="card-text review-text">Выполнили работу быстро, но мастер сказал что я небережно пользуюсь своим телефоном.</p>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex card-footer-review">
                    <div class="rating-result me-auto">
                        <span class="active"></span>
                        <span class="active"></span>
                        <span class="active"></span>
                        <span class="active"></span>
                        <span></span>
                    </div>
                    <div class="date ms-auto mt-4">
                        <p>27.02.2023</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <p class="mt-3 more_review">Ещё отзывы</p>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\SwiftFix\resources\views/main.blade.php ENDPATH**/ ?>