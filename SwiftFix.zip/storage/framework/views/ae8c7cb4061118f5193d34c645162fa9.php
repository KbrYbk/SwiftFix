

<?php $__env->startSection('content'); ?>
<!-- _________________________________Slogan_____________________________________________________ -->
<section class="slogan-container">
    <div class="container">
        <div class="slogan mb-5 row align-items-center">
            <div class="col-lg-6 order-lg-2">
                <h2 class="mb-4 slogan-top">Ремонт телефонов любой сложности</h2>
                <h2 class="slogan-text">Восстановите свою мобильную жизнь в мгновение ока!</h2>
            </div>
            <div class="col-lg-6 order-lg-1">
                <img src="<?php echo e(url('img/')); ?>/Pixel.png" alt="pixel7" class="pixel_on_slogan w-100">
            </div>
        </div>

    </div>
</section>
<!-- _________________________________Brand plates_______________________________________________ -->
<section class="container my-4">
    <h1 class="text-center my-5 name-section">Выберите модель вашего устройства</h1>
    <nav class="menu d-flex">
        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="nav-scroller__item">
            <a href="<?php echo e(url('/brandpage')); ?>/<?php echo e($bp->id); ?>" class="link">
                <div class="card cards-brands">
                    <img src="<?php echo e(asset('images/' . $bp->img)); ?>" alt="logo_brands" class="card-img-top">
                    <div class="card-body  d-flex align-items-center justify-content-center">
                        <h5 class="card-title-brand text-center"><?php echo e($bp->name); ?></h5>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
</section>
<!-- _________________________________Callback Form______________________________________________ -->
<section class="container my-4 ">
    <h1 class="text-center name-section mt-4">Нет подходящего бренда?</h1>
    <form action="<?php echo e(route('callback')); ?>" method="POST" class="mt-5 p-5 main-form" name="form1">
        <h1 class="text-center mb-4 name-block">Напишите модель вашего устройства,<br>мы вам обязательно позвоним</h1>
        <?php echo csrf_field(); ?>
        <div class="row align-items-center">
            <div class="col-12 col-lg mb-3">
                <input type="text" name="device_model" id="device_model" class="form-control" 
                placeholder="Модель вашего устройства" required>
                <?php $__errorArgs = ['device_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg mb-3">
                <input type="text" name="name" id="name" class="form-control" placeholder="Ваше имя" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg mb-3">
                <input type="text" name="phone_number" id="phone_number" class="form-control" 
                placeholder=" Ваш номер телефона" required>
                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg-2 mb-3 text-center">
                <button type="submit" class="btn btn-outline-secondary">Расчитать стоимость</button>
            </div>
        </div>
    </form>
</section>
<!-- _________________________________Additional services______________________________________________ -->
<section class="container my-4">
    <h1 class="text-center name-section my-5">Полная защита вашего телефона</h1>
    <div class="row additional_services align-items-center g-0">
        <div class="col-lg-6 order-lg-2 text-center">
            <h1 class="name-section mb-5 additional_services_name">Спасём от повторного <br>посещения</h1>
            <h4 class="additional_services_text">После ремонта в нашем сервисе установим на ваше устройство защитное стекло в подарок</h4>
        </div>
        <div class="col-lg-6 order-lg-1">
            <img src="<?php echo e(url('img/')); ?>/AdditionalServices.png" class="AdditionalServices_img w-100" alt="">
        </div>
    </div>
</section>
<!-- ______________________________Review__________________________________________ -->
<section class="container my-4" id="review">
    <h1 class="text-center name-section my-5">Отзывы наших клиентов</h1>


    <div class="row row-cols-1 row-cols-lg-2" id="reviewsContainer">
        <?php
        $visibleReviews = 2; // Количество отзывов, которые видны изначально
        ?>
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col mb-4 reviewCard" style="<?php echo e($index >= $visibleReviews ? 'display:none' : ''); ?>">
            <div class="card card_rev p-4 h-100">
                <div class="card-body card-body-rev">
                    <div class="row">
                        <div class="col-12 col-md-4 mb-3">
                            <img src="<?php echo e(asset('avatars/' . $review->user->avatar)); ?>" class=" avatar" 
                            alt="Аватарка пользователя">
                        </div>
                        <div class="col">
                            <h5 class="card-title review-name mb-3"><?php echo e($review->user->name); ?></h5>
                            <p class="card-text review-text"><?php echo e($review->content); ?></p>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex card-footer-review">
                    <div class="rating-result d-flex me-auto">
                        <?php for($i = 1; $i <= 5; $i++): ?> <?php if($i <=$review->rating): ?>
                            <span class="star-filled">★</span>
                            <?php else: ?>
                            <span class="star-empty">★</span>
                            <?php endif; ?>
                            <?php endfor; ?>
                    </div>
                    <div class="date ms-auto mt-4">
                        <p><?php echo e($review->created_at->format('d.m.Y')); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-3">
        <button type="button" class="btn btn-outline-secondary" id="toggleReviewsButton">
            <?php if(count($reviews) > $visibleReviews): ?>
            Ещё отзывы
            <?php else: ?>
            Скрыть отзывы
            <?php endif; ?>
        </button>
    </div>

    <script>
        $(document).ready(function() {
            var $reviewsContainer = $('#reviewsContainer');
            var $toggleReviewsButton = $('#toggleReviewsButton');
            var $reviewCards = $reviewsContainer.find('.reviewCard');
            var visibleReviews = <?php echo $visibleReviews; ?>;
            var totalReviews = <?php echo count($reviews); ?>;
            var reviewsHidden = true;

            $toggleReviewsButton.on('click', function() {
                for (var i = visibleReviews; i < totalReviews; i++) {
                    $reviewCards.eq(i).toggle(reviewsHidden);
                }

                $toggleReviewsButton.text(reviewsHidden ? 'Скрыть отзывы' : 'Ещё отзывы');
                reviewsHidden = !reviewsHidden;
            });
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u2054525/data/www/swift-fix.ru/resources/views/main.blade.php ENDPATH**/ ?>