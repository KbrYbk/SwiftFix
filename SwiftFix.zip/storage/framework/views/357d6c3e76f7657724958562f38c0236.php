

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-center mt-5">Админ панель</h1>

    <!-- Блок с заявками на обратный звонок -->
    <h4 class="text-center my-4">Заявки на обратный звонок</h4>
    <?php if($callback->isEmpty()): ?>
    <h4 class="text-center fst-italic my-4">Заявок на обратный звонок нет</h4>
    <?php else: ?>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-5">
        <?php $__currentLoopData = $callback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($ph->name); ?></h3>
                    <h4 class="card-text"><?php echo e($ph->phone_number); ?></h4>
                    <p class="card-text"><?php echo e($ph->device_model); ?></p>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(url('/admin/callback/delete/')); ?>/<?php echo e($ph->id); ?>" class="btn btn-outline-secondary">Удалить заявку</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <!-- Блок с брендами -->
    <h4 class="text-center my-4">Бренды</h4>
    <div class="menu d-flex">
        <?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="nav-scroller__item">
            <div class="card cards-brands h-100">
                <img src="<?php echo e(asset('images/' . $ph->img)); ?>" alt="logo_brands" class="card-img-top">
                <div class="card-body d-flex align-items-center justify-content-center">
                    <h5 class="card-title-brand text-center"><?php echo e($ph->name); ?></h5>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(url('/admin/brand/delete/')); ?>/<?php echo e($ph->id); ?>" class="btn btn-outline-secondary">Удалить бренд</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a href="<?php echo e(url('/brands/create')); ?>" class="btn btn-outline-secondary mt-3">Добавить бренд</a>
 
    <!-- Блок с услугами -->
    <h4 class="text-center my-4">Услуги</h4>
    <div class="row row-cols-5">
        <table class="table table-borderless table-striped-columns align-middle">
            <thead>
                <tr class="table-secondary">
                    <th scope="col" class="text-center col-8">Услуга</th>
                    <th scope="col" class="col-2">Цена</th>
                    <th scope="col" class="col-1">Действие</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-primary">
                    <th scope="row" class="col-8"><?php echo e($sv->name); ?></th>
                    <td class="col-2"><?php echo e($sv->price); ?></td>
                    <td class="col-1"><a href="<?php echo e(url('/admin/services/delete')); ?>/<?php echo e($sv->id); ?>" class="btn btn-outline-secondary">Удалить</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <a href="<?php echo e(url('/services/create')); ?>" class="btn btn-outline-secondary">Добавить услугу</a>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\SwiftFix\resources\views/admin.blade.php ENDPATH**/ ?>