<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center mt-4">
        <div class="col-md-11 mt-4">
            <div class="card card_rev p-4 h-100">
                <div class="card-body card-body-rev ">
                    <div class="row">
                        <div class="col-12 col-md-4 col-lg-3 col-xl-2 mb-3">
                            <img src="<?php echo e(asset('avatars/' . Auth::user()->avatar)); ?>" class=" avatar" alt="Аватарка пользователя">
                            <!-- <img src="<?php echo e(url('img/review')); ?>/Derden.png" class="w-100" alt="review_avatar w-100"> -->
                        </div>
                        <div class="col">
                            <?php if(Auth::check()): ?>
                            <h5 class="card-title review-name mb-3">Добро пожаловать, <?php echo e($user->name); ?>!</h5>
                            <p class="card-text review-text">Ваш электронный адрес: <?php echo e($user->email); ?></p>
                            <p class="card-text review-name mb-3">Загрузить фото пользователя:</p>
                            <!-- форма для смены аватарки -->
                            <form action="<?php echo e(route('avatar.upload')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <input class="form-control" type="file" id="formFile" name="avatar">
                                </div>
                                <button type="submit" class="btn btn-outline-secondary mt-3">Загрузить аватарку</button>
                            </form>
                            <!-- форма для отзыва -->
                            <p class="card-text review-name my-3">Оставте о нас отзыв:</p>

                            <form action="<?php echo e(route('reviews.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                    name="content" id="content" required></textarea>
                                </div>
                                <div class="rating mb-3">
                                    <input type="radio" id="star5" name="rating" value="5">
                                    <label for="star5" title="5 звезд"></label>
                                    <input type="radio" id="star4" name="rating" value="4">
                                    <label for="star4" title="4 звезды"></label>
                                    <input type="radio" id="star3" name="rating" value="3">
                                    <label for="star3" title="3 звезды"></label>
                                    <input type="radio" id="star2" name="rating" value="2">
                                    <label for="star2" title="2 звезды"></label>
                                    <input type="radio" id="star1" name="rating" value="1">
                                    <label for="star1" title="1 звезда"></label>
                                </div><br>
                                <?php
                                $hasReview = Auth::user()->reviews()->exists();
                                ?>

                                <button type="submit" class="btn btn-outline-secondary mt-3" <?php echo e($hasReview ? 'disabled' : ''); ?>>
                                    Отправить отзыв</button>
                                <!-- <button type="submit" class="btn btn-outline-secondary mt-3">Отправить отзыв</button> -->
                            </form>
                            <?php else: ?>
                            <p>Вы не вошли на сайт.</p>
                            <?php endif; ?>
                        </div>
                    </div>


                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\SwiftFix\resources\views/home.blade.php ENDPATH**/ ?>