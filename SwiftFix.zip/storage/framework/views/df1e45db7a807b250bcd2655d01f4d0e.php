<?php if($user->review): ?>
<h3>Ваш отзыв:</h3>
<p>Содержание: <?php echo e($user->review->content); ?></p>
<p>Рейтинг: <?php echo e($user->review->rating); ?></p>

<a href="<?php echo e(route('review.edit')); ?>">Редактировать отзыв</a>
<?php else: ?>
<h3>Оставить отзыв:</h3>
<form action="<?php echo e(route('review.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="content">Содержание:</label>
        <textarea name="content" id="content" rows="4" class="form-control" required></textarea>
    </div>

    <div class="form-group">
        <label for="rating">Рейтинг:</label>
        <input type="number" name="rating" id="rating" class="form-control" min="1" max="5" required>
    </div>

    <button type="submit" class="btn btn-primary">Отправить отзыв</button>
</form>
<?php endif; ?><?php /**PATH C:\OSPanel\domains\SwiftFix\resources\views/rew.blade.php ENDPATH**/ ?>