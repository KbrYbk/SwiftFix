

<?php $__env->startSection('content'); ?>
<div class="container pt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Добавление нового бренда</div>
                <div class="card-body">
                    <form action="<?php echo e(route('brands.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group mb-3">
                            <label for="name">Название бренда</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>

                        <div class="form-group mb-3">
                            <label for="formFile" class="form-label">Изображение бренда</label>
                            <input class="form-control" name="img" type="file" id="formFile" required>
                        </div>

                        <div class="form-group mb-3">
                            <label for="formFile" class="form-label">Изображение телефона на отдельной странице бренда</label>
                            <input class="form-control" name="img_slogan" type="file" id="formFile" required>
                        </div>

                        <div class="form-group mb-3">
                            <label for="exampleColorInput" class="form-label">Выберите цвет фона на отдельной странице бренда:</label>
                            <input type="color" name="color" class="form-control form-control-color" id="exampleColorInput" value="#ffffff" title="Choose your color">
                        </div>

                        <div class="form-group mb-3">
                            <label for="exampleColorInput" class="form-label">Выберите цвет текста на отдельной странице бренда:</label>
                            <input type="color" name="text" class="form-control form-control-color" id="exampleColorInput" value="#000000" title="Choose your color">
                        </div>

                        <button type="submit" class="btn btn-outline-secondary">Добавить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u2054525/data/www/swift-fix.ru/resources/views/addbrand.blade.php ENDPATH**/ ?>