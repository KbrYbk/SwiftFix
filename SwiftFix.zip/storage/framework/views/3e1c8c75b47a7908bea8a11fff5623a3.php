

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="slogan-container" style="background-color: <?php echo e($ph->color); ?>;">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="container">
        <div class="slogan mb-5 row align-items-center">
            <?php $__currentLoopData = $phone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 order-lg-2" style="color: <?php echo e($ph->text); ?>;">
                <h2 class="mb-4 slogan-top">Ремонт смартфонов <?php echo e($ph->name); ?></h2>
                <h2 class="slogan-text">Восстановите свою мобильную жизнь в мгновение ока!</h2>
            </div>
            <div class="col-lg-6 order-lg-1 text-center">
                <img src="<?php echo e(asset('images/' . $ph->img_slogan)); ?>" alt="<?php echo e($ph->name); ?>" class="pixel_on_slogan w-100">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<section class="container">
    <h1 class="text-center my-5 name-section">Сколько стоит ремонт телефона?</h1>
    <table class="table table-borderless table-striped-columns align-middle">
        <thead>
            <tr class="table-secondary">
                <th scope="col" class="text-center col-8">Услуга</th>
                <th scope="col" class="col-2">Цена</th>
                <th scope="col" class="text-center col-1 mobile-screen">Заказать</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="table-primary">
                <th scope="row" class="col-8"><?php echo e($sv->name); ?></th>
                <td class="col-2"><?php echo e($sv->price); ?></td>
                <td class="col-1 mobile-screen"><button type="submit" class="btn btn-outline-secondary">Расчитать стоимость</button></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</section>
<section class="container my-4 ">
    <h1 class="text-center name-section mt-4">Нет интересующей вас услуги?</h1>
    <form action="<?php echo e(route('callback')); ?>" method="POST" class="mt-5 p-5 main-form">
        <h1 class="text-center mb-4 name-block">Заполните форму и мы вам перезвоним</h1>
        <?php echo csrf_field(); ?>
        <div class="row align-items-center">
            <div class="col-12 col-lg mb-3">
                <input type="text" name="device_model" id="device_model" class="form-control" placeholder="Модель вашего устройства" required>
                <?php $__errorArgs = ['device_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg mb-3">
                <input type="text" name="name" id="name" class="form-control" placeholder="Ваше имя" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg mb-3">
                <input type="text" name="phone_number" id="phone_number" class="form-control" placeholder=" Ваш номер телефона" required>
                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-lg-2 mb-3 text-center">
                <button type="submit" class="btn btn-outline-secondary">Расчитать стоимость</button>
            </div>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\SwiftFix\resources\views/brandpage.blade.php ENDPATH**/ ?>